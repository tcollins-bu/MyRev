package com.revature.myrev.model;

public enum ERole {
	ROLE_USER, ROLE_ADMIN
}
